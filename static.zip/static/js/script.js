// script.js - JavaScript for Foodexa

// Go back to the saved place on the page.
// The place is saved just before a form is sent (see part 2d below).
// This runs straight away, so the page does not jump to the top first.
try {
    var savedScroll = JSON.parse(sessionStorage.getItem("keepScroll"));
    sessionStorage.removeItem("keepScroll");
    if (savedScroll && savedScroll.path === window.location.pathname) {
        window.scrollTo(0, savedScroll.y);

        // Some browsers move the page back to the top when loading finishes,
        // so we go back to the saved place once more at that moment
        window.addEventListener("load", function () {
            window.scrollTo(0, savedScroll.y);
        });
    }
} catch (error) {
    // If the browser does not allow storage, just skip it
}

// Run this code after the page has fully loaded
document.addEventListener("DOMContentLoaded", function () {

    // ---------- 1. Hamburger menu on small (phone) screens ----------
    var toggleButton = document.querySelector(".nav-toggle");
    var navLinks = document.querySelector(".nav-links");

    // Open the menu: show the links panel and turn the three lines into an X
    function openMenu() {
        navLinks.classList.add("open");
        toggleButton.classList.add("is-open");
        document.body.classList.add("menu-open");       // shows the see-through layer
        toggleButton.setAttribute("aria-expanded", "true");
        toggleButton.setAttribute("aria-label", "Close menu");
    }

    // Close the menu
    function closeMenu() {
        navLinks.classList.remove("open");
        toggleButton.classList.remove("is-open");
        document.body.classList.remove("menu-open");
        toggleButton.setAttribute("aria-expanded", "false");
        toggleButton.setAttribute("aria-label", "Open menu");
    }

    if (toggleButton && navLinks) {
        // The hamburger button opens the menu, or closes it if it is already open
        toggleButton.addEventListener("click", function () {
            if (navLinks.classList.contains("open")) {
                closeMenu();
            } else {
                openMenu();
            }
        });

        // Clicking the see-through layer behind the menu closes it
        document.querySelector(".nav-overlay").addEventListener("click", closeMenu);

        // Clicking any link inside the menu also closes it
        navLinks.querySelectorAll("a, button").forEach(function (link) {
            link.addEventListener("click", closeMenu);
        });
    }

    // ---------- 2. Flash messages ----------
    // Hide a message: add the "hiding" class so CSS fades it out,
    // then remove it from the page after 200 milliseconds.
    function hideMessage(message) {
        message.classList.add("hiding");
        setTimeout(function () {
            message.remove();
        }, 200);
    }

    var messages = document.querySelectorAll(".flash");

    messages.forEach(function (message) {
        // Close the message when its x button is clicked
        message.querySelector(".flash-close").addEventListener("click", function () {
            hideMessage(message);
        });

        // Success messages hide by themselves after 4 seconds.
        // Error messages stay until the user closes them.
        if (message.classList.contains("success")) {
            setTimeout(function () {
                hideMessage(message);
            }, 4000);
        }
    });

    // ---------- 2b. "Added to cart" toast (bottom right corner) ----------
    var toastArea = document.querySelector(".toast-area");

    // Show a small message in the bottom right corner for 3 seconds.
    // isLimit = true shows a red "Limit reached" message instead of "Added to cart".
    function showCartToast(message, cartCount, isLimit) {
        var toast = document.createElement("div");
        toast.className = isLimit ? "toast toast-limit" : "toast";
        toast.setAttribute("role", "status");
        toast.innerHTML =
            '<span class="toast-icon"><i class="fa-solid ' + (isLimit ? 'fa-exclamation' : 'fa-check') + '"></i></span>' +
            '<div class="toast-text"><strong>' + (isLimit ? 'Limit reached' : 'Added to cart') + '</strong><span></span></div>' +
            '<a href="/cart" class="toast-link">View cart (' + cartCount + ')</a>' +
            '<button type="button" class="toast-close" aria-label="Close">&times;</button>' +
            '<span class="toast-timer"></span>';        // the thin bar that shrinks in 3 seconds

        // textContent is used for the food name, so it is always shown as plain text
        toast.querySelector(".toast-text span").textContent = message;

        // Hide the toast: fade it out, then remove it
        function hideToast() {
            toast.classList.add("hiding");
            setTimeout(function () {
                toast.remove();
            }, 250);
        }

        toast.querySelector(".toast-close").addEventListener("click", hideToast);
        setTimeout(hideToast, 3000);

        // Only keep the 3 newest toasts on the screen
        if (toastArea.children.length >= 3) {
            toastArea.firstElementChild.remove();
        }
        toastArea.appendChild(toast);

        // Make the cart number in the navbar "bump" so the customer sees it went up
        // (not when the limit was reached, because then nothing was added)
        if (!isLimit) {
            document.querySelectorAll(".cart-count").forEach(function (count) {
                count.classList.remove("bump");
                void count.offsetWidth;                // lets the bump animation play again
                count.classList.add("bump");
            });
        }
    }

    // A cart message from the server (only when JavaScript was not used to add)
    var serverCartMessage = document.querySelector(".js-server-cart-message");
    if (serverCartMessage && toastArea) {
        var count = document.querySelector(".cart-count");
        showCartToast(serverCartMessage.getAttribute("data-message"), count ? count.textContent : "");
    }

    // ---------- 2c. "Add to cart" without reloading the page ----------
    // fetch() sends the form to the server in the background.
    // The page does not reload, so it stays exactly where it is.
    document.querySelectorAll(".js-add-to-cart").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            var button = event.submitter;

            // Only "Add to cart" is sent in the background.
            // "Order now" is sent normally, so it opens the cart page.
            if (!button || button.value !== "add") {
                return;
            }
            event.preventDefault();

            var formData = new FormData(form);
            formData.append("action", "add");
            button.disabled = true;

            // getAttribute("action") is used because the buttons in this form are
            // also named "action", and form.action would give us a button instead of the address
            fetch(form.getAttribute("action"), {
                method: "POST",
                body: formData,
                headers: { "X-Requested-With": "fetch" }    // tells app.py to answer with JSON
            })
            .then(function (response) {
                return response.json();
            })
            .then(function (result) {
                button.disabled = false;

                if (!result.ok) {
                    if (result.login_needed) {
                        window.location.href = "/login";
                    } else if (result.limit_reached) {
                        // Already 20 of this dish: show the message in red
                        var count = document.querySelector(".cart-count");
                        showCartToast(result.message, count ? count.textContent : "", true);
                    }
                    return;
                }

                // 1. Update every cart number on the page (navbar and phone cart icon)
                document.querySelectorAll(".cart-count").forEach(function (count) {
                    count.textContent = result.cart_count;
                });

                // 2. Show or update the "2 in cart" badge on this food card
                var actions = form.parentElement;
                var badge = actions.querySelector(".in-cart");
                if (!badge) {
                    badge = document.createElement("a");
                    badge.className = "in-cart";
                    badge.href = "/cart";
                    actions.appendChild(badge);
                }
                badge.innerHTML = '<i class="fa-solid fa-cart-shopping"></i> ' + result.item_count + " in cart";

                // 3. Show the small message in the bottom right corner
                showCartToast(result.message, result.cart_count);
            })
            .catch(function () {
                // If something went wrong, send the form the normal way instead
                button.disabled = false;
                form.submit();
            });
        });
    });

    // ---------- 2d. Stay in the same place after a form reloads the page ----------
    // Before a form is sent, remember how far down the page we are.
    // When the same page opens again, jump back to that place (see the top of this file).
    document.addEventListener("submit", function (event) {
        if (!event.defaultPrevented && event.target.getAttribute("method").toUpperCase() === "POST") {
            try {
                sessionStorage.setItem("keepScroll", JSON.stringify({
                    path: window.location.pathname,
                    y: window.scrollY
                }));
            } catch (error) {
                // If the browser does not allow storage, just skip it
            }
        }
    });

    // ---------- 2e. Category buttons on the menu page (no page reload) ----------
    // Every dish is already on the page. Clicking a category shows its dishes
    // and hides the others, so the page does not reload or jump.
    var categoryTabs = document.querySelectorAll(".js-category-tab");

    categoryTabs.forEach(function (tab) {
        tab.addEventListener("click", function (event) {
            event.preventDefault();
            var chosen = tab.getAttribute("data-category");   // "" means All
            var anyShown = false;

            // Mark the clicked button as active
            categoryTabs.forEach(function (otherTab) {
                otherTab.classList.toggle("active", otherTab === tab);
            });

            // Show the dishes of the chosen category, hide the rest
            document.querySelectorAll(".menu-group").forEach(function (group) {
                var show = (chosen === "" || group.getAttribute("data-category") === chosen);
                group.hidden = !show;
                if (show) {
                    anyShown = true;
                }
            });

            // Show "No dishes here" if the chosen category has nothing
            var emptyMessage = document.querySelector(".js-category-empty");
            if (emptyMessage) {
                emptyMessage.hidden = anyShown;
            }

            // Change the address bar to match (without reloading), e.g. /menu?category=2
            history.replaceState(null, "", tab.href);
        });
    });

    // Links to a part of the same page (like "Find us") scroll there smoothly
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
        link.addEventListener("click", function (event) {
            var target = document.querySelector(link.getAttribute("href"));
            if (target) {
                event.preventDefault();
                target.scrollIntoView({ behavior: "smooth" });
            }
        });
    });

    // ---------- 3. Login popup ----------
    // Visitors who are not logged in see this popup when they click
    // "Add to cart", "Order now" or "Cart".
    var modal = document.getElementById("login-modal");

    if (modal) {
        var modalText = document.getElementById("login-modal-text");
        var loginButtons = document.querySelectorAll(".js-login-required");
        var closeButtons = modal.querySelectorAll("[data-close-modal]");

        // Show the popup
        function openModal(foodName) {
            // If the button belongs to a food item, name the food in the message
            if (foodName) {
                modalText.textContent = "To order " + foodName + ", please log in or create a free account.";
            } else {
                modalText.textContent = "You need a Foodexa account to use the cart and place orders.";
            }
            modal.hidden = false;
            document.body.classList.add("modal-open");     // stop the page behind from scrolling
            modal.querySelector(".btn-primary").focus();   // keyboard users land on "Log in"
        }

        // Hide the popup
        function closeModal() {
            modal.hidden = true;
            document.body.classList.remove("modal-open");
        }

        loginButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                openModal(button.getAttribute("data-food"));
            });
        });

        // The x button and the dark area around the popup close it
        closeButtons.forEach(function (button) {
            button.addEventListener("click", closeModal);
        });
    }

    // ---------- 4. Place order button ----------
    // After the click, show "Placing order..." and disable the button,
    // so the customer cannot click twice and place the same order two times.
    var placeOrderForm = document.querySelector(".js-place-order");

    if (placeOrderForm) {
        placeOrderForm.addEventListener("submit", function () {
            var button = placeOrderForm.querySelector("button");
            button.disabled = true;
            button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Placing order...';
        });
    }

    // ---------- 5. Show / hide password (eye button) ----------
    // Changing the input type from "password" to "text" shows the password.
    document.querySelectorAll(".show-password").forEach(function (eyeButton) {
        eyeButton.addEventListener("click", function () {
            var input = eyeButton.parentElement.querySelector("input");
            var icon = eyeButton.querySelector("i");
            if (input.type === "password") {
                input.type = "text";
                icon.className = "fa-regular fa-eye-slash";
                eyeButton.setAttribute("aria-label", "Hide password");
            } else {
                input.type = "password";
                icon.className = "fa-regular fa-eye";
                eyeButton.setAttribute("aria-label", "Show password");
            }
        });
    });

    // ---------- 6. Confirmation popup (used everywhere) ----------
    // A form or link with data-confirm="question" shows our own popup first.
    // Extra settings (all optional):
    //   data-confirm-title  = the heading          (default "Are you sure?")
    //   data-confirm-yes    = text on the Yes button (default "Yes")
    //   data-confirm-type   = "danger" for delete / cancel (red button)
    //   data-confirm-icon   = a Font Awesome icon, e.g. "fa-solid fa-trash"
    var confirmBox = document.getElementById("confirm-box");
    var confirmYes = document.getElementById("confirm-box-yes");
    var onConfirmYes = null;        // what to do when "Yes" is clicked

    // Show the popup. "element" is the form or link that has the data-confirm settings.
    function askConfirm(element, whenYes) {
        var isDanger = element.getAttribute("data-confirm-type") === "danger";
        var icon = element.getAttribute("data-confirm-icon") ||
                   (isDanger ? "fa-solid fa-triangle-exclamation" : "fa-solid fa-circle-question");

        document.getElementById("confirm-box-title").textContent =
            element.getAttribute("data-confirm-title") || "Are you sure?";
        document.getElementById("confirm-box-text").textContent = element.getAttribute("data-confirm");
        document.getElementById("confirm-box-icon").innerHTML = '<i class="' + icon + '"></i>';
        confirmYes.textContent = element.getAttribute("data-confirm-yes") || "Yes";

        // Red style for dangerous actions
        confirmBox.classList.toggle("is-danger", isDanger);

        onConfirmYes = whenYes;
        confirmBox.hidden = false;
        document.body.classList.add("modal-open");
        confirmYes.focus();
    }

    function closeConfirmBox() {
        confirmBox.hidden = true;
        document.body.classList.remove("modal-open");
        onConfirmYes = null;
    }

    if (confirmBox) {
        confirmYes.addEventListener("click", function () {
            var action = onConfirmYes;
            closeConfirmBox();
            if (action) {
                action();
            }
        });

        // "Cancel", the x button and the dark area close the popup
        confirmBox.querySelectorAll("[data-confirm-close]").forEach(function (button) {
            button.addEventListener("click", closeConfirmBox);
        });

        // Forms with data-confirm: stop the form, ask first, then send it.
        // "true" means we catch the submit before any other code on the page sees it.
        // (The change password form is skipped here: it checks its boxes first, see part 7.)
        document.addEventListener("submit", function (event) {
            var form = event.target;
            var isPasswordForm = form.classList.contains("js-confirm-password");
            if (form.hasAttribute("data-confirm") && !isPasswordForm && form.getAttribute("data-confirmed") !== "yes") {
                event.preventDefault();
                event.stopPropagation();
                askConfirm(form, function () {
                    form.setAttribute("data-confirmed", "yes");
                    // requestSubmit() sends the form like a real click,
                    // so other code (like "Placing order...") still runs
                    if (form.requestSubmit) {
                        form.requestSubmit();
                    } else {
                        form.submit();
                    }
                });
            }
        }, true);

        // Links with data-confirm (for example Logout): ask first, then open the link
        document.querySelectorAll("a[data-confirm]").forEach(function (link) {
            link.addEventListener("click", function (event) {
                event.preventDefault();
                askConfirm(link, function () {
                    window.location.href = link.href;
                });
            });
        });
    }

    // ---------- 7. Change password: check the boxes, then ask "Are you sure?" ----------
    var passwordForm = document.querySelector(".js-confirm-password");

    if (passwordForm) {
        var errorText = passwordForm.querySelector(".form-error");

        passwordForm.addEventListener("submit", function (event) {
            // Stop the form for now. We send it only after "Yes" is clicked.
            event.preventDefault();

            var current = passwordForm.current_password.value;
            var newPassword = passwordForm.new_password.value;
            var confirmPassword = passwordForm.confirm_password.value;

            // Simple checks in the browser (the server checks again)
            if (current === "" || newPassword === "" || confirmPassword === "") {
                errorText.textContent = "Please fill in all three boxes.";
            } else if (newPassword.length < 6) {
                errorText.textContent = "The new password must be at least 6 characters long.";
            } else if (newPassword !== confirmPassword) {
                errorText.textContent = "The new passwords do not match.";
            } else if (newPassword === current) {
                errorText.textContent = "The new password must be different from your current password.";
            } else {
                errorText.textContent = "";
                askConfirm(passwordForm, function () {
                    passwordForm.submit();      // submit() skips this check, so it is sent
                });
            }
        });
    }

    // ---------- 8. Escape key closes the menu and the popups ----------
    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            if (navLinks && navLinks.classList.contains("open")) {
                closeMenu();
            }
            if (modal && !modal.hidden) {
                modal.hidden = true;
                document.body.classList.remove("modal-open");
            }
            if (confirmBox && !confirmBox.hidden) {
                closeConfirmBox();
            }
        }
    });
});
